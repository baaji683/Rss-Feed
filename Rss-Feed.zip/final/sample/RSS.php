<?php
header('Content-Type: application/xml');
?>
<rss version="2.0">
    <channel>
        <title>Your blog title</title>
        <link>http://www.blogurl.in</link>
        <description>RSS feed subscription.</description>
	<item>
            <title>Business</title>
            <link>http://timesofindia.indiatimes.com/rssfeeds/1898055.cms</link>
            <description>latest business news</description>
        </item>
        <item>
            <title>Sports</title>
            <link>http://timesofindia.indiatimes.com/rssfeeds/4719148.cms</link>
            <description>latest sports news</description>
        </item>
<?php
include "dconfig.php";
$sql = "SELECT * FROM article.data ORDER BY id DESC";
$result = $conn->query($sql) or die("Cannot write");
while($row = $result->fetch_assoc()){
?>
<item>
            <title><?php echo $row['title']; ?></title>
            <link><?php echo $row['link']; ?></link> //this link will be changed according to your post's URL
            <description><?php echo $row['description']; ?></description>
</item>
<?php
}
?>
</channel>
</rss>

