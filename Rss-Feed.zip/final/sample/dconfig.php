<?php
$host = 'localhost';
$db = 'demo';
$pwd = 'redhat';//replace with your db password
$uiser = 'root';//replace with your db username
$conn = new mysqli($host, $user, $pwd, $db) or die('cannot connect');
?>
