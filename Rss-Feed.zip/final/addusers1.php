<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>RSS Feed</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
<style>
#logo{
  height: 170px;
  width: 176px;
}</style>
</head>
<body>

    <div class="navbar navbar-inverse set-radius-zero" >
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="admin.php">

                    <img id="logo" src="assets/img/rss-icon.png" />
                </a>

            </div>

            <div class="right-div">
                <a href="logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
            </div>
        </div>
    </div>
    <!-- LOGO HEADER END-->
    <section class="menu-section">
        <div class="container">
            <div class="row ">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                            <li><a href="admin.php" class="menu-top-active">DASHBOARD</a></li>

                            <li>
                                <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown">USERS <i class="fa fa-angle-down"></i></a>
                                <ul class="dropdown-menu" role="menu" aria-labelledby="ddlmenuItem">
                                    <li role="presentation"><a role="menuitem" tabindex="-1" href="addusers1.php">ADD</a></li>
                                     <li role="presentation"><a role="menuitem" tabindex="-1" href="viewusers.php">SHOW</a></li>
                                     <li role="presentation"><a role="menuitem" tabindex="-1" href="updateform.php">EDIT</a></li>
                                     <li role="presentation"><a role="menuitem" tabindex="-1" href="delete.php">REMOVE</a></li>
                                </ul>
                            </li>
                       </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
     <!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">ADMIN DASHBOARD</h4>
            </div>
        </div>

        <div class="row">

            <div class="col-md-8 col-sm-8 col-xs-12">
                <div class="panel panel-success">
                   <div class="panel-heading">
                      Add users details here
                   </div>
                   <div class="panel-body">
            <form name="MyForm" class="form-horizontal" role="form" action="addusers11.php" method="post">
                <div class="form-group">
                    <label for="fullname" class="col-sm-3 control-label">Fullname</label>
                    <div class="col-sm-9">
                        <input type="text" name="fullname" placeholder=" Enter your fullname" class="form-control" autofocus required>
                        <span class="help-block">First Name, Last Name, Eg: Smith Harry</span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-3">Course</label>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" name="course" value="MCA" required>MCA
                                </label>
                            </div>
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" name="course" value="MBA" required>MBA
                                </label>
                            </div>
                        </div>
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <label for="username" class="col-sm-3 control-label">Username</label>
                    <div class="col-sm-9">
                        <input type="email" name="username" placeholder="Enter your email id" class="form-control" required>
                          <span class="help-block">Eg: username@gmail.com</span>
                    </div>
                </div>
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input type="password" name="password" placeholder="Enter your password" class="form-control" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="role" class="col-sm-3 control-label">Role</label>
                    <div class="col-sm-9">

                        <select name="role" class="form-control" required aria-required="true">
                            <option value="">--select--</option>
                            <option value="admin">admin</option>
                            <option value="faculty">faculty</option>
                            <option value="user">user</option>
                        </select>
                    </div>
                </div> <!-- /.form-group -->

                <div class="form-group">
                    <div class="col-sm-6 col-sm-offset-3">
                        <button type="submit" class="btn btn-success btn-block">Register</button>
                        <button type="reset" class="btn btn-default btn-block">Reset</button>
                    </div>
            </form> <!-- /form -->
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- CONTENT-WRAPPER SECTION END-->
 <section class="footer-section">
     <div class="container">
         <div class="row">
             <div class="col-md-11">
                &copy; On 2017, 151007@chintech.ac.in |<a href="#" target="_blank"  >  Designed by : Balaji Ramesh</a>
             </div>

         </div>
     </div>
 </section>
   <!-- FOOTER SECTION END-->
 <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
 <!-- CORE JQUERY  -->
 <script src="assets/js/jquery-1.10.2.js"></script>
 <!-- BOOTSTRAP SCRIPTS  -->
 <script src="assets/js/bootstrap.js"></script>
   <!-- CUSTOM SCRIPTS  -->
 <script src="assets/js/custom.js"></script>

 </body>
 </html>
