

    CREATE TABLE users (

        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,

        fullname VARCHAR(100) NOT NULL,

        course VARCHAR(3) NOT NULL,
	
	username VARCHAR(320) NOT NULL,

	password VARCHAR(255) NOT NULL,

	role VARCHAR(10) NOT NULL,
       
	created_at TIMESTAMP NOT NULL
    );


