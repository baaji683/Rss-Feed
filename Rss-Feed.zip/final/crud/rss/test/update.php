<?php
// Include config file
require_once 'config.php';

// Define variables and initialize with empty values
$name = $about = $sem = "";
$name_err = $about_err = $sem_err = "";

// Processing form data when form is submitted
if(isset($_POST["sid"]) && !empty($_POST["sid"])){
    // Get hidden input value
    $sid = $_POST["sid"];

    // Validate name
    $input_name = trim($_POST["name"]);
    if(empty($input_name)){
        $name_err = "Please enter a name.";
    } elseif(!filter_var(trim($_POST["name"]), FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
        $name_err = 'Please enter a valid name.';
    } else{
        $name = $input_name;
    }

    // Validate about
    $input_about = trim($_POST["about"]);
    if(empty($input_about)){
        $about_err = 'Please enter an description.';
    } else{
        $about = $input_about;
    }

    // Validate semester
    $input_sem = trim($_POST["sem"]);
    if(empty($input_sem)){
        $sem_err = "Please enter the semester.";
    } elseif(!ctype_digit($input_sem)){
        $sem_err = 'Please enter a positive integer value.';
    } else{
        $sem = $input_sem;
    }

    // Check input errors before inserting in database
    if(empty($name_err) && empty($about_err) && empty($sem_err)){
        // Prepare an insert statement
        $sql = "UPDATE subjects SET name=?, about=?, sem=? WHERE sid=?";

        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("sssi", $param_name, $param_about, $param_sem, $param_sid);

            // Set parameters
            $param_name = $name;
            $param_about = $about;
            $param_sem = $sem;
            $param_sid = $sid;

            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        $stmt->close();
    }

    // Close connection
    $mysqli->close();
} else{
    // Check existence of sid parameter before processing further
    if(isset($_GET["sid"]) && !empty(trim($_GET["sid"]))){
        // Get URL parameter
        $sid =  trim($_GET["sid"]);

        // Prepare a select statement
        $sql = "SELECT * FROM subjects WHERE sid = ?";
        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("i", $param_sid);

            // Set parameters
            $param_sid = $sid;

            // Attempt to execute the prepared statement
            if($stmt->execute()){
                $result = $stmt->get_result();

                if($result->num_rows == 1){
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    $row = $result->fetch_array(MYSQLI_ASSOC);

                    // Retrieve individual field value
                    $name = $row["name"];
                    $about = $row["about"];
                    $sem = $row["sem"];
                } else{
                    // URL doesn't contain valid sid. Redirect to error page
                    header("location: error.php");
                    exit();
                }

            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        $stmt->close();

        // Close connection
        $mysqli->close();
    }  else{
        // URL doesn't contain sid parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>RSS Feed</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <style type="text/css">
    #logo{
      height: 170px;
      width: 176px;
    }
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
  <div class="navbar navbar-inverse set-radius-zero" >
      <div class="container">
          <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="faculty.php">

                  <img id="logo" src="assets/img/rss-icon.png" />
              </a>

          </div>

          <div class="right-div">
              <a href="/cs/final/logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
          </div>
      </div>
  </div>
  <!-- LOGO HEADER END-->
  <section class="menu-section">
      <div class="container">
          <div class="row ">
              <div class="col-md-12">
                  <div class="navbar-collapse collapse ">
                      <ul id="menu-top" class="nav navbar-nav navbar-right">
                          <li><a href="/cs/final/faculty.php" class="menu-top-active">DASHBOARD</a></li>
                          <li><a href="index.php">SUBJECTS</a></li>
                     </ul>
                  </div>
              </div>

          </div>
      </div>
  </section>
   <!-- MENU SECTION END-->
  <div class="content-wrapper">
       <div class="container">
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Update Record</h2>
                    </div>
                    <p>Please edit the input values and submit to update the record.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group <?php echo (!empty($name_err)) ? 'has-error' : ''; ?>">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo $name; ?>">
                            <span class="help-block"><?php echo $name_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($about_err)) ? 'has-error' : ''; ?>">
                            <label>About</label>
                            <textarea name="about" class="form-control"><?php echo $about; ?></textarea>
                            <span class="help-block"><?php echo $about_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($sem_err)) ? 'has-error' : ''; ?>">
                            <label>Semester</label>
                            <input type="text" name="sem" class="form-control" value="<?php echo $sem; ?>">
                            <span class="help-block"><?php echo $sem_err;?></span>
                        </div>
                        <input type="hidden" name="sid" value="<?php echo $sid; ?>"/>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
  </div></div>
  <section class="footer-section">
      <div class="container">
          <div class="row">
              <div class="col-md-11">
                          &copy; On 2017, 151007@chintech.ac.in |<a href="#" target="_blank"  >  Designed by : Balaji Ramesh</a>
              </div>

          </div>
      </div>
  </section>
    <!-- FOOTER SECTION END-->
  <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
  <!-- CORE JQUERY  -->
  <script src="assets/js/jquery-1.10.2.js"></script>
  <!-- BOOTSTRAP SCRIPTS  -->
  <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
  <script src="assets/js/custom.js"></script>

</body>
</html>
