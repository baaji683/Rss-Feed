<?
	  class RSS
	  {
	    public function RSS()
	    {
	        require_once ('mysql_connect.php');
	    }
	    public function GetFeed()
	    {
	        return $this->getDetails() . $this->getItems();
	    }
	    private function dbConnect()
	    {
	        DEFINE ('LINK', mysql_connect (DB_HOST, DB_USER, DB_PASSWORD));
	    }
	    private function getDetails()
	    {
	        $detailsTable = "subjects";
	        $this->dbConnect($detailsTable);
	        $query = "SELECT * FROM ". $detailsTable;
	        $result = mysql_db_query (DB_NAME, $query, LINK);
	        while($row = mysql_fetch_array($result))
	        {
	            $details = '<?xml version="1.0" encoding="ISO-8859-1" ?>
	                <rss version="2.0">
	                    <channel>
	                        <title>'. $row['name'] .'</title>

	                        <description>'. $row['about'] .'</description>
	                    ';
	        }
	        return $details;
	    }
	    private function getItems()
	    {
	        $itemsTable = "items";
	        $this->dbConnect($itemsTable);
	        $query = "SELECT * FROM ". $itemsTable;
	        $result = mysql_db_query (DB_NAME, $query, LINK);
	        $items = '';
	        while($row = mysql_fetch_array($result))
	        {
	            $items .= '<item>
	                <title>'. $row["title"] .'</title>
	                <link>'. $row["link"] .'</link>
	                <description><![CDATA['. $row["descr"] .']]></description>
	            </item>';
	        }
	        $items .= '</channel>
	                </rss>';
	        return $items;
	    }
	}
	?>
