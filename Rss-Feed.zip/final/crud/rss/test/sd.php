<html>
<body>
<form method="post" action="rss.php">
  <input type="text" name="sid" placeholder=" sid" class="form-control" readonly required value="<?php echo trim($_GET["sid"]); ?>"/>
  <button type="submit" class="btn btn-warning btn-block" value="Submit the form">get Feed</button>
</form>
</body>
</html>
