    <?php

    /* Attempt MySQL server connection. Assuming you are running MySQL

    server with default setting (user 'root' with no password) */

    $link = mysqli_connect("localhost", "root", "redhat", "main");



    // Check connection

    if($link === false){

        die("ERROR: Could not connect. " . mysqli_connect_error());

    }




    // Attempt select query execution

    $sql = "SELECT subjects.name,items.title FROM subjects,items WHERE items.sid = subjects.sid ORDER BY subjects.name;";

    if($result = mysqli_query($link, $sql)){

        if(mysqli_num_rows($result) > 0){

            echo "<table>";

                echo "<tr>";

                    echo "<th>name</th>";

                    echo "<th>title</th>";

                    echo "<th>feeds</th>";
                echo "</tr>";

            while($row = mysqli_fetch_array($result)){

                echo "<tr>";

                    echo "<td>" . $row['name'] . "</td>";

                    echo "<td>" . $row['title'] . "</td>";

                  //  <a href='feedview.php?update={$row['employee_id']}'>{$row['employee_name']}</a>

			//echo '<td><a href="'.$row['sid'].'">'.$row['name'].'</a></td>';

//echo "<td><a href='index.php?sid='" . $row['sid'] . ">Post</a></td>";

//echo '<td><a href="http://localhost/cs/final/crud/rss/index.php'.$row['sid'].'">'.$row['name'].'</a></td>';
		/*<a href=$row[2]?channel=$row['0']>$row['name']?channel=$row['sid']</a>*/


                echo "</tr>";

            }

            echo "</table>";

            // Free result set

            mysqli_free_result($result);

        } else{

            echo "No records matching your query were found.";

        }

    } else{

        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

    }



    // Close connection

    mysqli_close($link);

    ?>
