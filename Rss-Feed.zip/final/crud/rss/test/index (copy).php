<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>RSS Feed</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <style type="text/css">
    #logo{
      height: 170px;
      width: 176px;
    }
        .wrapper{
            width: 650px;
            margin: 0 auto;
        }
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 15px;
        }
    </style>
    <script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
</head>
<body>
  <div class="navbar navbar-inverse set-radius-zero" >
      <div class="container">
          <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="faculty.php">

                  <img id="logo" src="assets/img/rss-icon.png" />
              </a>

          </div>

          <div class="right-div">
              <a href="/cs/final/logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
          </div>
      </div>
  </div>
  <!-- LOGO HEADER END-->
  <section class="menu-section">
      <div class="container">
          <div class="row ">
              <div class="col-md-12">
                  <div class="navbar-collapse collapse ">
                      <ul id="menu-top" class="nav navbar-nav navbar-right">
                          <li><a href="/cs/final/faculty.php" class="menu-top-active">DASHBOARD</a></li>
                          <li><a href="index.php">SUBJECTS</a></li>
                     </ul>
                  </div>
              </div>

          </div>
      </div>
  </section>
   <!-- MENU SECTION END-->
  <div class="content-wrapper">
       <div class="container">

    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header clearfix">
                        <h2 class="pull-left">Items Details</h2>
                    </div>
                    <?php
                    // Include config file
                    require_once 'config.php';

                    // Attempt select query execution
                    $sql = "SELECT * FROM items";
                    if($result = $mysqli->query($sql)){
                        if($result->num_rows > 0){
                            echo "<table class='table table-bordered table-striped'>";
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>#</th>";
                                        echo "<th>Title</th>";
                                        echo "<th>Link</th>";
                                        echo "<th>Description</th>";
                                        echo "<th>sub_id</th>";
                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = $result->fetch_array()){
                                    echo "<tr>";
                                        echo "<td>" . $row['id'] . "</td>";
                                        echo "<td>" . $row['title'] . "</td>";
                                        echo "<td>" . $row['link'] . "</td>";
                                        echo "<td>" . $row['descr'] . "</td>";
                                        echo "<td>" . $row['sid'] . "</td>";
                                        echo "<td>";
                                            echo "<a href='read.php?sid=". $row['sid'] ."' title='View Subject' data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>";
                                            echo "<a href='update.php?sid=". $row['sid'] ."' title='Update Subject' data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>";
                                            echo "<a href='delete.php?sid=". $row['sid'] ."' title='Delete Subject' data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>";
                                            echo "<a href='rss/items1.php?sid=". $row['sid'] ."' title='Add Feed' data-toggle='tooltip'><span class='glyphicon glyphicon-plus'></span></a>";
                                        echo "</td>";
                                    echo "</tr>";
                                }
                                echo "</tbody>";
                            echo "</table>";
                            // Free result set
                            $result->free();
                        } else{
                            echo "<p class='lead'><em>No records were found.</em></p>";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
                    }

                    // Close connection
                    $mysqli->close();
                    ?>
                </div>
            </div>
        </div>
    </div>
  </div></div>
  <section class="footer-section">
      <div class="container">
          <div class="row">
              <div class="col-md-11">
                          &copy; On 2017, 151007@chintech.ac.in |<a href="#" target="_blank"  >  Designed by : Balaji Ramesh</a>
              </div>

          </div>
      </div>
  </section>
    <!-- FOOTER SECTION END-->
  <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
  <!-- CORE JQUERY  -->
  <script src="assets/js/jquery-1.10.2.js"></script>
  <!-- BOOTSTRAP SCRIPTS  -->
  <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
  <script src="assets/js/custom.js"></script>

</body>
</html>
