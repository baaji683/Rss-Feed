<?php 
//connect to database, checking, etc 
$link = mysqli_connect("localhost", "root", "redhat", "main");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


// process form when posted
if(isset($_POST['value'])) {
	if($_POST['value'] == '1') {
		// query to get all Fitzgerald records  
		$query = "SELECT * FROM subjects WHERE sem='1'";  
	}  
	elseif($_POST['value'] == '4') {  
		// query to get all Herring records  
		$query = "SELECT * FROM subjects WHERE sem='4'";  
	} else {  
		// query to get all records  
		$query = "SELECT * FROM subjects";  
	}  
	$sql = mysql_query($query);  
	
	while ($row = mysql_fetch_array($query)){ 
		$sid = $row["sid"]; 
		$name = $row["name"]; 
		$sem = $row["sem"]; 
		
		// Echo your rows here... 
		echo 'The subid is:' . $row['sid'];
	}
	mysql_close($con); 
}
?>
<html>
<head></head>
<body>
<form action='<?php echo $_SERVER['PHP_SELF']; ?>' method='post' name='form_filter' > 
	<select name="value"> 
		<option value="all">All</option> 
		<option value="1">1</option> 
		<option value="4">4</option> 
	</select> 
	<br /> 
	<input type='submit' value = 'Filter'> 
</form>
</body>
</html>
