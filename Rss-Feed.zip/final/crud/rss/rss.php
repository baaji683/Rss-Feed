<?php

// PDO connect *********
function connect() {
    return new PDO('mysql:host=localhost;dbname=main', 'root', 'redhat', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
}

$pdo = connect();
//$id = $_GET['sid'];
//$subject_id=$_GET["sid"];
//echo $id;
// posts *******************************


$sql = "SELECT * FROM items WHERE sid = $_GET[sid] ORDER BY id DESC";
//echo $sql;
//$sql = 'SELECT * FROM items WHERE sid= "4"';
$query = $pdo->prepare($sql);
$query->execute();
$rs_post = $query->fetchAll();

// The XML structure
$data = '<?xml version="1.0" encoding="UTF-8" ?>';
$data .= '<rss version="2.0">';
foreach ($rs_post as $row) {
$data .= '<channel>';
$data .= '<title>RSS Feeds : subject_id='.$row['sid'].'</title>';
//$data .= '<link>151007@chintech.ac.in</link>';
$data .= '<description>Free to subscribe and we feed you with regular updates  ~ Balaji Ramesh</description>';
foreach ($rs_post as $row) {
//  $data .= '<title>subject_id='.$row['sid'].'</title>';
    $data .= '<item>';
    $data .= '<title>'.$row['title'].'</title>';
    $data .= '<link>'.$row['link'].'</link>';
    $data .= '<description>'.$row['descr'].'</description>';
    $data .= '</item>';
}
$data .= '</channel>';
}
$data .= '</rss> ';

header('Content-Type: application/xml');
echo $data;
?>
