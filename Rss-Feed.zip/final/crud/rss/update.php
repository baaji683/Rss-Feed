<?php
mysql_connect("localhost", "root", "redhat") or die("Connection Failed");
mysql_select_db("main")or die("Connection Failed");
$id = $_POST['id'];
$title = $_POST['title'];
$link = $_POST['links'];
$descr = $_POST['descr'];


//$query = "UPDATE users SET fullname = '$fullname' , course = '$course' , username = '$username' , password = '$password' , role = '$role' , created_at = CURRENT_TIMESTAMP  WHERE id = '$id' NOT EXISTS";
$query = "UPDATE items SET title = '$title' , links = '$link' , descr = '$descr'  WHERE id = '$id'";


if(mysql_query($query)){
//echo "Record updated successfully";
echo '<script language="javascript">';
echo 'alert("Record updated successfully");';
echo 'window.location= "viewrss.php";';
echo '</script>';
}
else{
//echo "Record updation failed, Try later..!";
echo '<script language="javascript">';
echo 'alert("Record updation failed, Try later..!");';
echo 'window.location= "updateform.php";';
echo '</script>';
}
?>
