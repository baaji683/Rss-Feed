<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>RSS Feed</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <style type="text/css">
    #logo{
      height: 170px;
      width: 176px;
    }
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
        .alert-success{
          width: 95rem;
          height: 40rem;
        }
    </style>
  </head>
  <body>
    <div class="navbar navbar-inverse set-radius-zero" >
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="faculty.php">

                    <img id="logo" src="assets/img/rss-icon.png" />
                </a>

            </div>

            <div class="right-div">
                <a href="/cs/final/logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
            </div>
        </div>
    </div>
    <!-- LOGO HEADER END-->
    <section class="menu-section">
        <div class="container">
            <div class="row ">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                            <li><a href="/cs/final/faculty.php" class="menu-top-active">DASHBOARD</a></li>
                            <li><a href="/cs/final/crud/index.php">SUBJECTS</a></li>
                       </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
     <!-- MENU SECTION END-->
    <div class="content-wrapper">
    <div class="container">
      <div class="alert alert-warning">
        <img src="images/RSS.png" />
  <strong><span class="glyphicon glyphicon-ok-circle"></span>Success!</strong> Item added successful in your database.

</div>
        <h1 class="main_title">An RSS Feed with PHP and MySQL</h1>
        <div class="content">
            <a href="viewrss.php" class="btn btn-warning">Show added RSS feed</a>
        </div><!-- content -->

    </div><!-- container -->
  </div>
  <section class="footer-section">
      <div class="container">
          <div class="row">
              <div class="col-md-11">
                          &copy; On 2017, 151007@chintech.ac.in |<a href="#" target="_blank"  >  Designed by : Balaji Ramesh</a>
              </div>

          </div>
      </div>
  </section>
    <!-- FOOTER SECTION END-->
  <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
  <!-- CORE JQUERY  -->
  <script src="assets/js/jquery-1.10.2.js"></script>
  <!-- BOOTSTRAP SCRIPTS  -->
  <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
  <script src="assets/js/custom.js"></script>

  </body>
  </html>
