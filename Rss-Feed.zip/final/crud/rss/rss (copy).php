<?php

// PDO connect *********
function connect() {
    return new PDO('mysql:host=localhost;dbname=main', 'root', 'redhat', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
}

$pdo = connect();
$subject_id=$_GET["subject"];
//echo $sid;
// posts *******************************
$sql = 'SELECT * FROM items WHERE sid="$subject_id"';
$query = $pdo->prepare($sql);
$query->execute();
$rs_post = $query->fetchAll();

// The XML structure
$data = '<?xml version="1.0" encoding="UTF-8" ?>';
$data .= '<rss version="2.0">';
$data .= '<channel>';
$data .= '<title>RSS feeds</title>';
$data .= '<link>151007@chintech.ac.in</link>';
$data .= '<description>Free to subscribe and we feed you with regular updates</description>';
foreach ($rs_post as $row) {
    $data .= '<item>';
    $data .= '<title>'.$row['title'].'</title>';
    $data .= '<link>'.$row['link'].'</link>';
    $data .= '<description>'.$row['descr'].'</description>';
    $data .= '</item>';
}
$data .= '</channel>';
$data .= '</rss> ';

header('Content-Type: application/xml');
echo $data;
?>
