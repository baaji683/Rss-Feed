<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "redhat", "main");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Escape user inputs for security
$title = mysqli_real_escape_string($link, $_REQUEST['title']);
$links = mysqli_real_escape_string($link, $_REQUEST['links']);
$descr = mysqli_real_escape_string($link, $_REQUEST['descr']);
$sid = mysqli_real_escape_string($link, $_REQUEST['sid']);
$message = "Feed added successful. Thank you!";


// attempt insert query execution
$sql = "INSERT INTO items (title,links,descr,sid) VALUES ('$title', '$links', '$descr','$sid')";
if(mysqli_query($link, $sql)){
    echo "<script type='text/javascript'>alert('$message');window.location.href='/cs/final/crud/rss/index.php';</script>";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

// close connection
mysqli_close($link);
?>
