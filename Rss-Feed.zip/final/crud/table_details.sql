

    CREATE TABLE subjects (

        sid INT NOT NULL PRIMARY KEY AUTO_INCREMENT,

        name VARCHAR(100) NOT NULL,

        about VARCHAR(255) NOT NULL,

        sem INT(10) NOT NULL

    );


