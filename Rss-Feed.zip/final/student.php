﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>RSS Feed</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
<style>
#logo{
  height: 170px;
  width: 176px;
}</style>
</head>
<body>

    <div class="navbar navbar-inverse set-radius-zero" >
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="student.php">

                    <img id="logo" src="assets/img/rss-icon.png" />
                </a>

            </div>

            <div class="right-div">
                <a href="logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
            </div>
        </div>
    </div>
    <!-- LOGO HEADER END-->
    <section class="menu-section">
        <div class="container">
            <div class="row ">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                            <li><a href="student.php" class="menu-top-active">DASHBOARD</a></li>
                            <li><a href="crud/rss/getrss.php">SUBSCRIBE RSS FEEDS</a></li>
                       </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
     <!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">STUDENT DASHBOARD</h4>
            </div>
        </div>

             <div class="row">

                 <div class="col-md-3 col-sm-3 col-xs-6">
                      <div class="alert alert-info back-widget-set text-center">
                            <i class="fa fa-history fa-5x"></i>
                            <h3>500+ Feeds</i></h3>
                           Amount Pending For Adding
                        </div>
                    </div>
              <div class="col-md-3 col-sm-3 col-xs-6">
                      <div class="alert alert-success back-widget-set text-center">
                            <i class="fa fa-bars fa-5x"></i>
                            <h3>300+ Tasks</h3>
                            Pending For New Events
                        </div>
                    </div>
               <div class="col-md-3 col-sm-3 col-xs-6">
                      <div class="alert alert-warning back-widget-set text-center">
                            <i class="fa fa-recycle fa-5x"></i>
                            <h3>56+ Faculty</h3>
                           To Be Made For New Way
                        </div>
                    </div>
               <div class="col-md-3 col-sm-3 col-xs-6">
                      <div class="alert alert-danger back-widget-set text-center">
                            <i class="fa fa-briefcase fa-5x"></i>
                            <h3>30+ Issues </h3>
                            That Should Be Resolved Now
                        </div>
                    </div>

        </div>
             <div class="row">

              <div class="col-md-8 col-sm-8 col-xs-12">
                    <div id="carousel-example" class="carousel slide slide-bdr" data-ride="carousel" >

                    <div class="carousel-inner">
                        <div class="item active">
                            <img src="assets/img/111.jpg" alt="" />
                        </div>
                    </div>

                    <!--PREVIUS-NEXT BUTTONS-->
                </div>
              </div>

                 <div class="col-md-4 col-sm-4 col-xs-12">
                 <div class="panel panel-warning ">
                        <div class="panel-heading">
                            Recent Chat History
                        </div>
                        <div class="panel-body chat-widget-main">
                            <div class="chat-widget-left">
                              RSS (Rich Site Summary) is a format for delivering regularly changing web content.
                            </div>
                            <div class="chat-widget-name-left">
                                <img class="media-object img-circle img-left-chat" src="assets/img/user2.png" />
                                <h4>  Amanna Seiar</h4>
                                <h5>Time 2:00 pm at 25th july</h5>
                            </div>
                            <hr />
                            <div class="chat-widget-right">
                              Many news-related sites, weblogs and other online publishers syndicate their content as an RSS Feed to whoever wants it.
                            </div>
                            <div class="chat-widget-name-right">
                                 <img class="media-object img-circle img-right-chat" src="assets/img/user2.png" />
                                <h4>  Amanna Seiar</h4>
                                <h5>Time 2:00 pm at 25th july</h5>
                            </div>
                            <hr />
                            <div class="chat-widget-left">
                                RSS solves a problem for people who regularly use the web. It allows you to easily stay informed by retrieving the latest content from the sites you are interested in. You save time by not needing to visit each site individually. You ensure your privacy, by not needing to join each site's email newsletter. The number of sites offering RSS feeds is growing rapidly and includes big names like Yahoo News.
                            </div>
                            <div class="chat-widget-name-left">
                                 <img class="media-object img-circle img-left-chat" src="assets/img/user2.png" />
                                <h4>  Amanna Seiar</h4>
                                <h5>Time 2:00 pm at 25th july</h5>
                            </div>
                            <hr />
                            <div class="chat-widget-right">
                                  Feed Reader or News Aggregator software allow you to grab the RSS feeds from various sites and display them for you to read and use.
                            </div>
                            <div class="chat-widget-name-right">
                               <img class="media-object img-circle img-right-chat" src="assets/img/user2.png" />
                                <h4>  Amanna Seiar</h4>
                                <h5>Time 2:00 pm at 25th july</h5>
                            </div>
                            <hr />
                        </div>

                    </div>
             </div>

                 </div>

             <div class="row">

                 <div class="col-md-8 col-sm-8 col-xs-12">
                     <div class="panel panel-warning">
                        <div class="panel-heading">
                           Recent Comments
                        </div>
                        <div class="panel-body">
                            <ul class="media-list">

      <li class="media">
        <a class="pull-left" href="#">
          <img class="media-object img-circle img-comments" src="assets/img/user.gif" />
        </a>
        <div class="media-body">
          <h4 class="media-heading">Stay with rss </h4>
          <p>
              Staying up to date with everything on the internet that interests you is challenging. Instead of visiting many of the same websites every day, you can instead take advantage of RSS—short for Really Simple Syndication—to gather headlines from those sites and either feed them directly to your computer or app automatically or place them at a website you view online. If you want additional information about the story behind the headline, you can always click on the headline to read more.
          </p>
          <!-- Nested media object -->
          <div class="media">
            <a class="pull-left" href="#">
              <img class="media-object img-circle img-comments" src="assets/img/user2.png">
            </a>
            <div class="media-body">
              <h4 class="media-heading">RSS Aggregators </h4>
              You customize your RSS feed to have websites of your choice deliver their latest news directly to your screen. Instead of having to visit 15 different places to get your weather, sports, favorite photos, latest gossip or latest political debates, you just go to one screen and see the highlights of all those websites combined into a single window.

  The RSS headlines and stories are available immediately. Once published at the source server, RSS headlines take only moments to get to your screen.
              <!-- Nested media object -->
              <div class="media">
                <a class="pull-left" href="#">
                 <img class="media-object img-circle img-comments" src="assets/img/user.gif" />
                </a>
                <div class="media-body">
                  <h4 class="media-heading">Reasons You Might Enjoy RSS </h4>
                     When you copy the RSS URL and paste it into your RSS reader, you are "subscribing" to the feed. It will deliver results to your RSS reader until you unsubscribe from it.
                </div>
              </div>
            </div>
          </div>

        </div>
      </li>

    </ul>
                            </div>
                         </div>

                 </div>
                 <div class="col-md-4 col-sm-4 col-xs-12" >
                        <div class="alert alert-danger text-center">
                          <h3> IMPORTANT NOTICE</h3>
                          <hr />
                            <i class="fa fa-warning fa-4x"></i>
                          <p>
                            RSS stands for both Rich Site Summary and Really Simple Syndication but it always refers to the same technology.

   It is a mean of transmitting and updating news in an automated way.

   Most news sites (including virtually all blogs) will publish what is called an RSS feed which is regularly updated with the latest available headlines and/or articles.

   The RSS feed is not human readable. It is an XML format which is designed to be read by machines rather than humans.
                        </p>
                          <hr />
                           <a href="#" class="btn btn-danger">Read Full Detalis</a>
                        </div>
                 </div>
             </div>


    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
    <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-11">
                            &copy; On 2017, 151007@chintech.ac.in |<a href="#" target="_blank"  >  Designed by : Balaji Ramesh</a>
                </div>

            </div>
        </div>
    </section>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>

</body>
</html>
